package com.example.myappnews;

import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private ImageView imageView;
    private RecyclerView recyclerView;
    private List<NewsFeed> newsFeedList = new ArrayList<>();
    private NewsAdapter newsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
        NewsFeedPrepare();
    }

    private void NewsFeedPrepare() {

        String url = "https://newsapi.org/v2/everything?q=bitcoin&from=2021-02-28&sortBy=publishedAt&apiKey=API_KEY";
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                recyclerView = findViewById(R.id.news122);
                imageView = findViewById(R.id.image_news);
                newsAdapter = new NewsAdapter(newsFeedList);
                RecyclerView.LayoutManager manager = new GridLayoutManager(getApplicationContext(), 1);
                recyclerView.setLayoutManager(manager);
                recyclerView.setAdapter(newsAdapter);
                JSONArray jsonArray = null;
                try {
                    jsonArray = response.getJSONArray("articles");
                    NewsFeed newsFeed = new NewsFeed(jsonArray.getJSONObject(0).get("title").toString(), jsonArray.getJSONObject(0).get("description").toString(), jsonArray.getJSONObject(0).get("url").toString(), jsonArray.getJSONObject(0).get("urltoImage").toString(), imageView);
                    for (int i = 1, size = jsonArray.length(); i < size; i++) {

                        JSONObject objectinArray = jsonArray.getJSONObject(i);
                        newsFeed = new NewsFeed(objectinArray.get("title").toString(), objectinArray.get("description").toString(), objectinArray.get("url").toString(), objectinArray.get("urltoImage").toString(), imageView);
                        newsFeedList.add(newsFeed);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "ERROR", Toast.LENGTH_LONG).show();
            }
        }) {

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("User-Agent", "Mozilla/5.0");
                return headers;
            }
        };
        requestQueue.add(jsonObjectRequest);
    }
}