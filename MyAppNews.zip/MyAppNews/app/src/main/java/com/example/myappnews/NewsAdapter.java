package com.example.myappnews;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder> {
    List<NewsFeed> newsFeedList;

    public NewsAdapter(List<NewsFeed> newsFeedList) {
        this.newsFeedList = newsFeedList;


    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.newsshape, parent, false);
        return new NewsViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        NewsFeed newsFeed = newsFeedList.get(position);
        holder.description.setText(newsFeed.description);
        holder.title.setText(newsFeed.title);
        holder.url = newsFeed.url;
        Picasso.get().load(newsFeed.urltoImage).into(holder.imageView);

    }

    @Override
    public int getItemCount() {
        return newsFeedList.size();
    }


    public class NewsViewHolder extends RecyclerView.ViewHolder {
        TextView description, title;
        ImageView imageView;
        String url;
        LinearLayout parent;

        public NewsViewHolder(@NonNull View itemView) {
            super(itemView);
            description = itemView.findViewById(R.id.description_news);
            title = itemView.findViewById(R.id.title_news);
            imageView = itemView.findViewById(R.id.image_news);
            parent = itemView.findViewById(R.id.parent);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(itemView.getContext(), webActivity.class); // TODO : WILL CREATE LATER
                    intent.putExtra("url", url);
                    itemView.getContext().startActivity(intent);

                }
            });


        }
    }
}
