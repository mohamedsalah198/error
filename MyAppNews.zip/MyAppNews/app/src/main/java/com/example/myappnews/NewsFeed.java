package com.example.myappnews;

import android.widget.ImageView;

public class NewsFeed {
    String title;
    String description;
    ImageView imageView;
    String url;
    String urltoImage;

    public NewsFeed(String title, String description, String url, String urltoImage, ImageView imageView) {
        this.title = title;
        this.description = description;
        this.imageView = imageView;
        this.url = url;
        this.urltoImage = urltoImage;
    }
}
